<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
            📦 Private Items (Login Required)
        </h2>
    </x-slot>

    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl sm:rounded-lg p-6">
                @if ($items->count())
                    <div class="overflow-x-auto">
                        <table class="min-w-full border border-gray-200 divide-y divide-gray-200 rounded-md shadow-sm">
                            <thead class="bg-gray-100 text-gray-700">
                                <tr>
                                    <th class="px-6 py-3 text-left text-sm font-semibold uppercase tracking-wider">ID</th>
                                    <th class="px-6 py-3 text-left text-sm font-semibold uppercase tracking-wider">Item Name</th>
                                    <th class="px-6 py-3 text-left text-sm font-semibold uppercase tracking-wider">Description</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-100">
                                @foreach ($items as $item)
                                    <tr class="hover:bg-gray-50 transition">
                                        <td class="px-6 py-4 text-sm text-gray-900">{{ $item->id }}</td>
                                        <td class="px-6 py-4 text-sm font-medium text-blue-700">{{ $item->item_name }}</td>
                                        <td class="px-6 py-4 text-sm text-gray-600">{{ $item->description }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    {{-- Optional Pagination --}}
                    <div class="mt-6">
                        {{ $items->links() }}
                    </div>
                @else
                    <div class="text-center text-gray-500 py-12">
                        <svg class="mx-auto w-16 h-16 text-gray-300" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 6.75h4.5m-7.5 10.5h10.5m-12-3h13.5m-3-3H6.75m0-3h10.5m-3 9.75v.008h.008V18.75H14.25zm0 0a.75.75 0 11-1.5 0m1.5 0a.75.75 0 10-1.5 0" />
                        </svg>
                        <p class="mt-4 text-lg">No items found</p>
                        <p class="text-sm text-gray-400">You haven’t added any private items yet.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
